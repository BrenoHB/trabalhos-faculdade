namespace VitalMoveDTO
{
    public class IMCRequestDTO
    {
        public string? Usuario { get; set; }
    }
}