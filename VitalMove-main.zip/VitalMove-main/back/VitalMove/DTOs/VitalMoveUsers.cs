namespace VitalMoveDTO
{
    public class UserLoginDTO
    {
        public string? CPF { get; set; }
        public string? Password { get; set; }
    }
}