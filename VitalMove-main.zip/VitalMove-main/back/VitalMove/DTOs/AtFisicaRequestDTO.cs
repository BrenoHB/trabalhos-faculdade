namespace VitalMoveDTO
{
    public class AtFisicaRequestDTO
    {
        public string? Usuario { get; set; }
    }
}