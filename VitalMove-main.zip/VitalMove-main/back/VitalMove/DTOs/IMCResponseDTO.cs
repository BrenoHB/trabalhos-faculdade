namespace VitalMoveDTO
{
    public class IMCResponseDTO
    {
        public double IMC { get; set; }
        public double Altura { get; set; }
        public double Peso { get; set; }
        public string? Usuario { get; set; }
    }
}