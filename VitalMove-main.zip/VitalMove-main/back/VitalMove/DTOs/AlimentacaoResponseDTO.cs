namespace VitalMoveDTO
{
    public class AlimentacaoResponseDTO
    {
        public string? Horario { get; set; }
        public double KCAL { get; set; }
        public string? Comentario { get; set; }
        public string? Usuario { get; set; }
        public string? Alimentos { get; set; }
    }
}