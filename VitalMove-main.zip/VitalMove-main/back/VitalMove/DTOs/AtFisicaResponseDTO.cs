namespace VitalMoveDTO
{
    public class AtFisicaResponseDTO
    {
        public string? Modalidade { get; set; }
        public int Tempo { get; set; }
        public int Distancia { get; set; }
        public double KCAL { get; set; }
        public int TempoD { get; set; }
        public string? Usuario { get; set; }
    }
}