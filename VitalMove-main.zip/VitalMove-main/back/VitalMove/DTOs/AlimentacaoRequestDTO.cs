namespace VitalMoveDTO
{
    public class AlimentacaoRequestDTO
    {
        public string? Usuario { get; set; }
    }
}